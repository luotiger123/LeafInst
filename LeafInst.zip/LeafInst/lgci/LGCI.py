"""
LGCI computation and visualization script.

This script performs the following steps:
1. Run instance segmentation inference on input images.
2. Match predicted instances with ground-truth instances using IoU.
3. Extract geometric and color-related phenotypic indicators.
4. Compute evaluation metrics (R², RMSE, MAE).
5. Calculate the Leaf Growth Condition Indicator (LGCI) score using
   entropy-based feature weights.
6. Export visualizations and analysis tables.

Main outputs:
- Instance visualization images
- Score-only visualization maps
- Scatter comparison plots
- Error plots
- Excel tables with evaluation metrics and analyzed results

Notes
-----
- This script is designed for forestry leaf phenotyping analysis.
- The LGCI score is computed from normalized geometric and color-related
  features extracted from predicted leaf instances.
- The segmentation model is assumed to be built with MMDetection.

Author
------
Your Name / Lab / Project Name
"""

import os
import argparse

import cv2
import numpy as np
import pandas as pd
import torch
import matplotlib.pyplot as plt

from matplotlib.ticker import AutoMinorLocator
from matplotlib.colors import Normalize, ListedColormap
from scipy.stats import gaussian_kde
from sklearn.metrics import r2_score, mean_squared_error, mean_absolute_error
from pycocotools.coco import COCO

from mmdet.apis import init_detector, inference_detector
from palettable.scientific.sequential import Nuuk_20 as TheColor


# -------------------------------------------------------------------------
# Global plotting style
# -------------------------------------------------------------------------
plt.style.use('seaborn-whitegrid')
plt.rcParams['font.sans-serif'] = ['Arial']
plt.rcParams['axes.unicode_minus'] = False


# -------------------------------------------------------------------------
# Optimal values for intermediate color-related indicators
# These are used to transform "mid-type" indicators into positive indicators
# in the LGCI calculation.
# -------------------------------------------------------------------------
mid_indices = {
    'gt_R_median': 80.017307,
    'gt_G_median': 111.681990,
    'gt_B_median': 41.394267,
    'gt_R_mean': 82.495153,
    'gt_G_mean': 113.095326,
    'gt_B_mean': 44.447823,
    'gt_R_1/3_quantile': 73.709032,
    'gt_G_1/3_quantile': 105.491076,
    'gt_B_1/3_quantile': 34.396431,
    'gt_R_2/3_quantile': 87.145484,
    'gt_G_2/3_quantile': 118.376420,
    'gt_B_2/3_quantile': 49.360736
}


# -------------------------------------------------------------------------
# Entropy-based feature weights used for LGCI
# -------------------------------------------------------------------------
weights = {
    'width': 0.149537,
    'height': 0.105731,
    'perimeter': 0.132912,
    'area': 0.296493,
    'roundness': 0.058775,
    'rectangularity': 0.027970,
    'R_median': 0.015785,
    'G_median': 0.027783,
    'B_median': 0.013530,
    'R_mean': 0.016005,
    'G_mean': 0.027056,
    'B_mean': 0.012718,
    'R_1/3_quantile': 0.014014,
    'G_1/3_quantile': 0.023614,
    'B_1/3_quantile': 0.011313,
    'R_2/3_quantile': 0.018213,
    'G_2/3_quantile': 0.032739,
    'B_2/3_quantile': 0.015814
}


# -------------------------------------------------------------------------
# Colormap for score visualization
# -------------------------------------------------------------------------
cmap = ListedColormap(['#00FFFF', '#00FF00', '#FF0000'])
norm = Normalize(vmin=0, vmax=1)


def normalize_mid_feature(pred_values, optimal_value, eps=1e-8):
    """Convert a mid-type indicator into a positive normalized indicator.

    The closer the value is to the optimal value, the higher the score.

    Args:
        pred_values (np.ndarray): Predicted values.
        optimal_value (float): Optimal reference value.
        eps (float): Numerical stability term.

    Returns:
        np.ndarray: Normalized positive indicator.
    """
    delta = np.abs(pred_values - optimal_value)
    max_delta = np.max(delta) + eps
    normalized = 1 - (delta / max_delta)
    return normalized


def normalize_features(df, features, method='minmax'):
    """Normalize selected features in a dataframe.

    Args:
        df (pd.DataFrame): Input dataframe.
        features (list[str]): Feature names to normalize.
        method (str): Normalization method. Currently only 'minmax'.

    Returns:
        pd.DataFrame: Dataframe with normalized features.
    """
    norm_df = df.copy()
    for feat in features:
        if method == 'minmax':
            min_val = np.min(norm_df[feat])
            max_val = np.max(norm_df[feat])
            if max_val == min_val:
                norm_df[feat] = 0.5
            else:
                norm_df[feat] = (norm_df[feat] - min_val) / (max_val - min_val)
    return norm_df


def get_uniform_colors(num_instances):
    """Generate visually distinct colors for instance visualization.

    Args:
        num_instances (int): Number of instances.

    Returns:
        list[tuple]: List of (mask_color, box_color) tuples.
    """
    colors = plt.cm.tab20(np.linspace(0, 1, num_instances))
    colors = [(int(c[0] * 200), int(c[1] * 200), int(c[2] * 200)) for c in colors]
    box_color = (0, 0, 0)
    return [(mask_color, box_color) for mask_color in colors]


def apply_mask(image, mask, color, alpha=0.8):
    """Apply a colored mask with contour rendering.

    Args:
        image (np.ndarray): Input image.
        mask (np.ndarray): Binary mask.
        color (tuple): RGB color.
        alpha (float): Mask transparency.

    Returns:
        np.ndarray: Masked image.
    """
    color_mask = np.zeros_like(image)
    color_mask[:] = color
    masked = cv2.addWeighted(image, 1 - alpha, color_mask, alpha, 0)

    contours, _ = cv2.findContours(
        mask.astype(np.uint8), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE
    )
    for contour in contours:
        cv2.drawContours(masked, [contour], -1, (0, 0, 0), 2, lineType=cv2.LINE_AA)

    return np.where(mask[..., None], masked, image)


def visualize_results(image, bboxes, masks, labels, scores, class_names,
                      score_thr=0.3, instance_ids=None):
    """Visualize predicted masks, bounding boxes, IDs, and scores.

    Args:
        image (np.ndarray): Input RGB image.
        bboxes (np.ndarray): Predicted boxes.
        masks (np.ndarray): Predicted binary masks.
        labels (np.ndarray): Predicted labels.
        scores (np.ndarray): Prediction scores.
        class_names (list[str]): Class names.
        score_thr (float): Score threshold.
        instance_ids (np.ndarray or list, optional): Instance IDs.

    Returns:
        np.ndarray: Visualization image.
    """
    keep = scores >= score_thr
    bboxes = bboxes[keep]
    masks = masks[keep]
    scores = scores[keep]
    labels = np.array(labels)[keep] if len(labels) > 0 else []

    if instance_ids is None:
        instance_ids = list(range(1, len(bboxes) + 1))
    else:
        instance_ids = instance_ids[keep]

    if len(bboxes) == 0:
        return image

    colors = get_uniform_colors(len(bboxes))
    vis_image = np.ones_like(image) * 255

    for i, (mask, (mask_color, box_color)) in enumerate(zip(masks, colors)):
        vis_image = apply_mask(vis_image, mask, mask_color, alpha=0.8)
        x1, y1, x2, y2 = map(int, bboxes[i])
        cv2.rectangle(vis_image, (x1, y1), (x2, y2), box_color, 2)

    for instance_id, (mask, score) in zip(instance_ids, zip(masks, scores)):
        y_indices, x_indices = np.where(mask)
        if len(y_indices) == 0 or len(x_indices) == 0:
            continue

        center_y = int(np.mean(y_indices))
        center_x = int(np.mean(x_indices))

        id_text = f"ID:{instance_id}"
        score_text = f"S:{score:.2f}"

        font = cv2.FONT_HERSHEY_SIMPLEX
        font_scale = 0.6
        thickness = 2

        id_size = cv2.getTextSize(id_text, font, font_scale, thickness)[0]
        score_size = cv2.getTextSize(score_text, font, font_scale, thickness)[0]
        total_height = id_size[1] + score_size[1] + 5

        tx = center_x
        ty = center_y - total_height // 2

        x1_box = tx - max(id_size[0], score_size[0]) // 2
        y1_box = ty - id_size[1] - 3
        x2_box = tx + max(id_size[0], score_size[0]) // 2
        y2_box = ty + score_size[1] + 3

        cv2.rectangle(vis_image, (x1_box, y1_box), (x2_box, y2_box),
                      (0, 0, 0), -1, cv2.LINE_AA)
        cv2.rectangle(vis_image, (x1_box, y1_box), (x2_box, y2_box),
                      (255, 255, 255), 1, cv2.LINE_AA)

        cv2.putText(vis_image, id_text,
                    (tx - id_size[0] // 2, ty + id_size[1]),
                    font, font_scale, (255, 255, 255), thickness, cv2.LINE_AA)

        cv2.putText(vis_image, score_text,
                    (tx - score_size[0] // 2, ty + id_size[1] + score_size[1] + 2),
                    font, font_scale, (255, 255, 255), thickness, cv2.LINE_AA)

    if len(labels) > 0:
        for i, (bbox, score, label) in enumerate(zip(bboxes, scores, labels)):
            x1, y1, x2, y2 = map(int, bbox)
            label_text = f"{class_names[label]}: {score:.2f}"
            (text_w, text_h), _ = cv2.getTextSize(
                label_text, cv2.FONT_HERSHEY_SIMPLEX, 0.5, 1
            )
            overlay = vis_image.copy()
            cv2.rectangle(overlay, (x1, y1 - text_h - 5), (x1 + text_w, y1),
                          (50, 50, 50), -1)
            cv2.addWeighted(overlay, 0.7, vis_image, 0.3, 0, vis_image)
            cv2.putText(vis_image, label_text, (x1, y1 - 5),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 2)

    return vis_image


def get_instance_parameters(mask, image):
    """Extract geometric and color-related phenotypic indicators.

    Args:
        mask (np.ndarray): Binary instance mask.
        image (np.ndarray): RGB image.

    Returns:
        tuple: width, height, perimeter, area,
               median_rgb, mean_rgb, q1_rgb, q2_rgb,
               roundness, rectangularity
    """
    contours, _ = cv2.findContours(
        mask.astype(np.uint8), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE
    )
    if len(contours) == 0:
        return 0, 0, 0, 0, [0] * 3, [0] * 3, [0] * 3, [0] * 3, 0, 0

    cnt = contours[0]
    area = cv2.contourArea(cnt)
    perimeter = cv2.arcLength(cnt, True)
    x, y, w, h = cv2.boundingRect(cnt)

    roundness = 4 * np.pi * area / (perimeter ** 2) if perimeter != 0 else 0
    rect = cv2.minAreaRect(cnt)
    (_, _), (rect_w, rect_h), _ = rect
    rect_area = rect_w * rect_h
    rectangularity = area / rect_area if rect_area != 0 else 0

    masked_pixels = image[mask.astype(bool)]
    if len(masked_pixels) == 0:
        return w, h, perimeter, area, [0] * 3, [0] * 3, [0] * 3, [0] * 3, roundness, rectangularity

    r, g, b = masked_pixels[:, 0], masked_pixels[:, 1], masked_pixels[:, 2]
    median = [np.median(ch) for ch in [r, g, b]]
    mean = [np.mean(ch) for ch in [r, g, b]]
    q1 = [np.quantile(ch, 1 / 3) for ch in [r, g, b]]
    q2 = [np.quantile(ch, 2 / 3) for ch in [r, g, b]]

    return w, h, perimeter, area, median, mean, q1, q2, roundness, rectangularity


def calculate_metrics(y_true, y_pred):
    """Compute R², RMSE, and MAE."""
    r2 = r2_score(y_true, y_pred)
    rmse = np.sqrt(mean_squared_error(y_true, y_pred))
    mae = mean_absolute_error(y_true, y_pred)
    return r2, rmse, mae


def plot_scatter_comparison(df, output_dir):
    """Plot scatter comparison between prediction and ground truth."""
    pred_columns = [
        col for col in df.columns
        if col.startswith('pred_') and col != 'pred_instance_identifier'
    ]
    gt_columns = [col.replace('pred_', 'gt_') for col in pred_columns]
    custom_cmap = TheColor.mpl_colormap

    for pred_col, gt_col in zip(pred_columns, gt_columns):
        fig, ax = plt.subplots(figsize=(12, 6))
        x = df[gt_col]
        y = df[pred_col]
        xy = np.vstack([x, y])
        z = gaussian_kde(xy)(xy)

        scatter = ax.scatter(
            x, y, c=z, cmap=custom_cmap, alpha=0.8, s=20,
            edgecolor='white', linewidth=0.5
        )

        lims = [
            np.min([ax.get_xlim(), ax.get_ylim()]),
            np.max([ax.get_xlim(), ax.get_ylim()])
        ]
        ax.plot(lims, lims, 'k--', lw=2)
        ax.fill_between(
            lims,
            lims[0] - np.std(df[pred_col] - df[gt_col]),
            lims[1] + np.std(df[pred_col] - df[gt_col]),
            color='gray', alpha=0.2
        )

        ax.set_xlabel(f'GT - {gt_col.split("_", 1)[-1]}', fontsize=18)
        ax.set_ylabel(f'Pred - {pred_col.split("_", 1)[-1]}', fontsize=18)
        ax.set_title(f'Comparison Analysis: {gt_col.split("_", 1)[-1]}',
                     fontsize=16, fontweight='bold')
        ax.grid(linestyle='--', alpha=0.6)
        ax.tick_params(axis='both', which='major', labelsize=12)
        ax.xaxis.set_minor_locator(AutoMinorLocator(2))
        ax.yaxis.set_minor_locator(AutoMinorLocator(2))

        cbar = plt.colorbar(scatter, ax=ax)
        cbar.set_label('Density', fontsize=12)

        r2, rmse, mae = calculate_metrics(df[gt_col], df[pred_col])
        metrics_text = f'R² = {r2:.4f}\nRMSE = {rmse:.4f}\nMAE = {mae:.4f}'
        ax.text(
            0.05, 0.95, metrics_text, transform=ax.transAxes, fontsize=12,
            verticalalignment='top',
            bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.5)
        )

        safe_name = gt_col.split("_", 1)[-1].replace('/', '_')
        plot_path = os.path.join(output_dir, f'comparison_{safe_name}.png')
        plt.savefig(plot_path, dpi=300, bbox_inches='tight')
        plt.close(fig)


def plot_error_scatter(df, output_dir):
    """Plot prediction error scatter maps."""
    pred_columns = [
        col for col in df.columns
        if col.startswith('pred_') and col != 'pred_instance_identifier'
    ]
    gt_columns = [col.replace('pred_', 'gt_') for col in pred_columns]
    custom_cmap = TheColor.mpl_colormap

    for pred_col, gt_col in zip(pred_columns, gt_columns):
        error = df[pred_col] - df[gt_col]
        fig, ax = plt.subplots(figsize=(12, 6))
        x = df[gt_col]
        y = error
        xy = np.vstack([x, y])
        z = gaussian_kde(xy)(xy)

        scatter = ax.scatter(
            x, y, c=z, cmap=custom_cmap, alpha=0.8, s=20,
            edgecolor='white', linewidth=0.5
        )

        ax.axhline(y=0, color='k', linestyle='--', lw=2)
        ax.fill_between(
            [df[gt_col].min(), df[gt_col].max()],
            -np.std(error), np.std(error),
            color='gray', alpha=0.2
        )

        ax.set_xlabel(f'GT - {gt_col.split("_", 1)[-1]}', fontsize=18)
        ax.set_ylabel(f'Error (Pred - GT) - {gt_col.split("_", 1)[-1]}', fontsize=18)
        ax.set_title(f'Error Analysis: {gt_col.split("_", 1)[-1]}',
                     fontsize=16, fontweight='bold')
        ax.grid(linestyle='--', alpha=0.6)
        ax.tick_params(axis='both', which='major', labelsize=12)
        ax.xaxis.set_minor_locator(AutoMinorLocator(2))
        ax.yaxis.set_minor_locator(AutoMinorLocator(2))

        cbar = plt.colorbar(scatter, ax=ax)
        cbar.set_label('Density', fontsize=12)

        r2, rmse, mae = calculate_metrics(df[gt_col], df[pred_col])
        metrics_text = f'R² = {r2:.4f}\nRMSE = {rmse:.4f}\nMAE = {mae:.4f}'
        ax.text(
            0.05, 0.95, metrics_text, transform=ax.transAxes, fontsize=12,
            verticalalignment='top',
            bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.5)
        )

        safe_name = gt_col.split("_", 1)[-1].replace('/', '_')
        plot_path = os.path.join(output_dir, f'error_{safe_name}.png')
        plt.savefig(plot_path, dpi=300, bbox_inches='tight')
        plt.close(fig)


def visualize_scores_only(masks, scores, output_path):
    """Visualize LGCI scores only with a white background.

    Args:
        masks (list[np.ndarray]): Instance masks.
        scores (np.ndarray): Normalized LGCI scores in [0, 1].
        output_path (str): Output path for the score map.
    """
    height, width = masks[0].shape
    vis_image = np.ones((height, width, 3), dtype=np.uint8) * 255

    score_cmap = plt.get_cmap('Greens')
    score_norm = Normalize(vmin=0, vmax=1)
    scores = np.clip(scores, 0, 1)

    colors = score_cmap(score_norm(scores))
    colors = [(int(c[0] * 255), int(c[1] * 255), int(c[2] * 255)) for c in colors]

    for mask, color in zip(masks, colors):
        contours, _ = cv2.findContours(
            mask.astype(np.uint8), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE
        )
        cv2.drawContours(vis_image, contours, -1, color, -1)
        cv2.drawContours(vis_image, contours, -1, (0, 0, 0), 1)

    fig, ax = plt.subplots()
    fig.subplots_adjust(right=0.8)
    cbar_ax = fig.add_axes([0.85, 0.15, 0.05, 0.7])

    sm = plt.cm.ScalarMappable(cmap=score_cmap, norm=score_norm)
    sm.set_array([])
    fig.colorbar(sm, cax=cbar_ax, label='Score (0 - 1)')

    ax.imshow(cv2.cvtColor(vis_image, cv2.COLOR_BGR2RGB))
    ax.axis('off')

    plt.savefig(output_path, dpi=300, bbox_inches='tight')
    plt.close(fig)


def calculate_scores(df, weights, mid_indices):
    """Calculate LGCI scores.

    The workflow includes:
    1. Positive transformation of mid-type indicators
    2. Min-max normalization
    3. Weighted summation using entropy-based weights

    Args:
        df (pd.DataFrame): Input dataframe with predicted indicators.
        weights (dict): Entropy weights.
        mid_indices (dict): Optimal values for mid-type indicators.

    Returns:
        np.ndarray: LGCI scores.
    """
    mid_features = [f for f in weights.keys() if any(key in f for key in ['R_', 'G_', 'B_'])]
    other_features = [f for f in weights.keys() if f not in mid_features]

    norm_df = df.copy()

    for feat in mid_features:
        optimal_key = f"gt_{feat}"
        optimal_value = mid_indices[optimal_key]
        pred_col = f"pred_{feat}"
        norm_df[pred_col] = normalize_mid_feature(norm_df[pred_col].values, optimal_value)

    for feat in other_features:
        pred_col = f"pred_{feat}"
        norm_df = normalize_features(norm_df, [pred_col])

    score = np.zeros(len(norm_df))
    for col in norm_df.columns:
        if col.startswith('pred_') and col not in ['pred_instance_identifier', 'pred_score']:
            feat = col.split("_", 1)[-1]
            if feat in weights:
                score += norm_df[col] * weights[feat]

    return score


def get_gt_instance_parameters(coco, img_id, img, class_names):
    """Extract ground-truth instance parameters from COCO annotations."""
    ann_ids = coco.getAnnIds(imgIds=img_id)
    anns = coco.loadAnns(ann_ids)

    gt_data = []
    gt_masks = []

    for ann in anns:
        instance_id = ann['id']
        category_id = ann['category_id']
        _ = class_names.index(coco.loadCats(category_id)[0]['name'])
        mask = coco.annToMask(ann)

        (width, height, perimeter, area, median_rgb, mean_rgb,
         one_third_q, two_thirds_q, roundness, rectangularity) = get_instance_parameters(mask, img)

        if area < 1500:
            continue

        gt_data.append({
            'gt_instance_identifier': f"gt_{instance_id}",
            'gt_width': width,
            'gt_height': height,
            'gt_perimeter': perimeter,
            'gt_area': area,
            'gt_roundness': roundness,
            'gt_rectangularity': rectangularity,
            'gt_R_median': median_rgb[0],
            'gt_G_median': median_rgb[1],
            'gt_B_median': median_rgb[2],
            'gt_R_mean': mean_rgb[0],
            'gt_G_mean': mean_rgb[1],
            'gt_B_mean': mean_rgb[2],
            'gt_R_1/3_quantile': one_third_q[0],
            'gt_G_1/3_quantile': one_third_q[1],
            'gt_B_1/3_quantile': one_third_q[2],
            'gt_R_2/3_quantile': two_thirds_q[0],
            'gt_G_2/3_quantile': two_thirds_q[1],
            'gt_B_2/3_quantile': two_thirds_q[2]
        })
        gt_masks.append(mask)

    return gt_data, gt_masks


def calculate_iou(mask1, mask2):
    """Calculate IoU between two binary masks."""
    intersection = np.logical_and(mask1, mask2).sum()
    union = np.logical_or(mask1, mask2).sum()
    if union == 0:
        return 0
    return intersection / union


def main():
    """Main pipeline for LGCI computation and visualization."""
    parser = argparse.ArgumentParser(
        description='Instance segmentation analysis and LGCI visualization'
    )
    parser.add_argument(
        '--config',
        default='',
        help='Path to the model configuration file'
    )
    parser.add_argument(
        '--checkpoint',
        default='',
        help='Path to the model checkpoint file'
    )
    parser.add_argument(
        '--img_dir',
        default='',
        help='Path to the image directory'
    )
    parser.add_argument(
        '--output_dir',
        default='',
        help='Path to the output directory'
    )
    parser.add_argument(
        '--score_thr',
        type=float,
        default=0.3,
        help='Confidence score threshold'
    )
    parser.add_argument(
        '--gt_annotation_file',
        default='',
        help='Path to the COCO-format ground truth annotation file'
    )
    parser.add_argument(
        '--iou_threshold',
        type=float,
        default=0.5,
        help='IoU threshold for matching predicted and GT instances'
    )
    args = parser.parse_args()

    os.makedirs(args.output_dir, exist_ok=True)

    device = 'cuda:0' if torch.cuda.is_available() else 'cpu'
    model = init_detector(args.config, args.checkpoint, device=device)
    class_names = ['leaf']
    all_bound_data = []

    coco = COCO(args.gt_annotation_file)

    for img_id in coco.getImgIds():
        img_info = coco.loadImgs(img_id)[0]
        img_name = img_info['file_name']
        img_path = os.path.join(args.img_dir, img_name)
        output_path = os.path.join(args.output_dir, img_name)

        img = cv2.imread(img_path)
        img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        img_brightness_adj = cv2.convertScaleAbs(img_rgb, alpha=1.1, beta=5)

        result = inference_detector(model, img_brightness_adj)

        if hasattr(result, 'pred_instances'):
            instances = result.pred_instances
            bboxes = instances.bboxes.cpu().numpy()
            scores = instances.scores.cpu().numpy()
            labels = instances.labels.cpu().numpy()
            masks = instances.masks.cpu().numpy()
        else:
            bboxes = result[0][0][:, :4]
            scores = result[0][0][:, 4]
            labels = result[0][0][:, 5].astype(int)
            masks = result[1][0]

        keep = scores >= args.score_thr
        bboxes = bboxes[keep]
        masks = masks[keep]
        labels = labels[keep]
        scores = scores[keep]
        instance_count = len(bboxes)

        instance_ids = np.arange(1, instance_count + 1)

        vis_img = visualize_results(
            img_brightness_adj, bboxes, masks, labels, scores,
            class_names, args.score_thr, instance_ids
        )
        text = f"Predicted instances: {instance_count}"
        cv2.putText(vis_img, text, (10, 30),
                    cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 255), 2)
        vis_img_bgr = cv2.cvtColor(vis_img, cv2.COLOR_RGB2BGR)
        cv2.imwrite(output_path, vis_img_bgr)
        print(f"Visualization result saved: {output_path}, "
              f"Number of predicted instances: {instance_count}")

        gt_data, gt_masks = get_gt_instance_parameters(coco, img_id, img_rgb, class_names)

        for i, mask in enumerate(masks):
            (width, height, perimeter, area, median_rgb, mean_rgb,
             one_third_q, two_thirds_q, roundness, rectangularity) = get_instance_parameters(mask, img_rgb)

            if area < 1500:
                continue

            instance_id = instance_ids[i]
            combined_id = f"{img_name}-{instance_id}"

            max_iou = 0
            best_gt_index = -1
            for j, gt_mask in enumerate(gt_masks):
                iou = calculate_iou(mask, gt_mask)
                if iou > max_iou:
                    max_iou = iou
                    best_gt_index = j

            if max_iou >= args.iou_threshold:
                gt_info = gt_data[best_gt_index]
                bound_data = {
                    'pred_instance_identifier': combined_id,
                    'instance_number': instance_id,
                    'pred_width': width,
                    'pred_height': height,
                    'pred_perimeter': perimeter,
                    'pred_area': area,
                    'pred_roundness': roundness,
                    'pred_rectangularity': rectangularity,
                    'pred_R_median': median_rgb[0],
                    'pred_G_median': median_rgb[1],
                    'pred_B_median': median_rgb[2],
                    'pred_R_mean': mean_rgb[0],
                    'pred_G_mean': mean_rgb[1],
                    'pred_B_mean': mean_rgb[2],
                    'pred_R_1/3_quantile': one_third_q[0],
                    'pred_G_1/3_quantile': one_third_q[1],
                    'pred_B_1/3_quantile': one_third_q[2],
                    'pred_R_2/3_quantile': two_thirds_q[0],
                    'pred_G_2/3_quantile': two_thirds_q[1],
                    'pred_B_2/3_quantile': two_thirds_q[2],
                    'mask': mask,
                    **gt_info
                }
                all_bound_data.append(bound_data)

    bound_df = pd.DataFrame(all_bound_data)

    plot_scatter_comparison(bound_df, args.output_dir)
    plot_error_scatter(bound_df, args.output_dir)

    scores = calculate_scores(bound_df, weights, mid_indices)
    bound_df['pred_score'] = scores

    for img_id in coco.getImgIds():
        img_info = coco.loadImgs(img_id)[0]
        img_name = img_info['file_name']
        pred_instances = bound_df[
            bound_df['pred_instance_identifier'].str.startswith(img_name)
        ]
        if pred_instances.empty:
            continue

        masks = pred_instances['mask'].values
        scores_map = pred_instances['pred_score'].values
        scores_normalized = (
            (scores_map - scores_map.min()) /
            (scores_map.max() - scores_map.min() + 1e-8)
        )

        output_path = os.path.join(args.output_dir, f"score_visualization_{img_name}")
        visualize_scores_only(masks, scores_normalized, output_path)
        print(f"Score visualization result saved: {output_path}")

    metrics_df = pd.DataFrame(columns=['Feature', 'R²', 'RMSE', 'MAE'])
    for pred_col in [
        col for col in bound_df.columns
        if col.startswith('pred_') and col not in ['pred_instance_identifier', 'pred_score']
    ]:
        gt_col = pred_col.replace('pred_', 'gt_')
        if gt_col in bound_df.columns:
            r2, rmse, mae = calculate_metrics(bound_df[gt_col], bound_df[pred_col])
            feature_name = pred_col.split('_', 1)[-1]
            metrics_df = pd.concat([
                metrics_df,
                pd.DataFrame({
                    'Feature': [feature_name],
                    'R²': [r2],
                    'RMSE': [rmse],
                    'MAE': [mae]
                })
            ], ignore_index=True)

    metrics_df.to_excel(os.path.join(args.output_dir, 'evaluation_metrics.xlsx'), index=False)
    print("Metrics saved to evaluation_metrics.xlsx")

    bound_df.to_excel(os.path.join(args.output_dir, 'analyzed_results.xlsx'), index=False)
    print("Analysis completed. Results saved to analyzed_results.xlsx")


if __name__ == '__main__':
    main()